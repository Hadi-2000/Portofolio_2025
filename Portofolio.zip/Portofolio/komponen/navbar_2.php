<!--Navbar-->
<nav class="navbar bg-body-tertiary">
        <div class="container-fluid">
            <a class="navbar-brand" href="../index.php">Hadi Wicaksono</a>
            <div>
                <button class="btn" type="submit"><a class="text-decoration-none hover-text-primary-emphasis nav-link" onclick="setActiveLinkNav(this)" href="projects.php">Projects</a></button>
                <button class="btn" type="submit"><a class="text-decoration-none hover-text-primary-emphasis nav-link" onclick="setActiveLinkNav(this)" href="aboutme.php">About Me</a></button>
                <button class="btn" type="submit"><a class="text-decoration-none hover-text-primary-emphasis nav-link" onclick="setActiveLinkNav(this)" href="contact.php">Contact</a></button>
                <button class="btn" type="submit"><a class="text-decoration-none hover-text-primary-emphasis nav-link" >Change Theme</a></button>
            </div>
        </div>
      </nav>
   <!--Navbar-->

   